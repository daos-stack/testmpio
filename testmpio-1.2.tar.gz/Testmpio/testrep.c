/*===========================================================================
 *
 * Name:  testrep.c
 *
 * Functions:
 *	dotests
 *	main
 *	test_errors
 *	test_readwriteexternal32
 *	test_readwriteinternal
 *	test_readwriteuser
 *	test_scaling
 *	test_setgetrep
 *
 *	DecodeType
 *	FailRep_converter
 *	FillBuf
 *	ShowMap
 *	TextRep_extent
 *	TextRep_read_converter
 *	TextRep_write_converter
 *	UserTypeMapCopy
 *	UserTypeMapDelete
 *	UserTypemapInit
 *
 * Description:
 *	Tests MPI-IO datarep conversion features.
 *
 * Traceability:
 *	Version		Date		Description
 *	-------		----		-----------
 *	0.1		03/??/98	initital attempts
 *	0.2		03/25/98	fixes for macros & other bugs
 *	0.3		03/26/98	added checks for erroneous cases
 *	0.4		04/29/98	added to MPIO_TESTS
 *	1.0P		05/12/98	initial public release
 *	1.1P		05/12/98	removed old comment
 *	1.2P		05/13/98	fixed type definitions in test_scaling
 *	1.3P		06/10/98	completed error checking
 *
 * Notes:
 *	See the accompanying file LEGAL-NOTICE for disclaimers and
 *	information on commercial use.
 *	
 *-------------------------------------------------------------------------*/


#include "mpi.h"

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

#include "external32data.h"
#include "textdata.h"

/* Things to try:
 * Setting each of the built-in datareps produces no error and
 * returns the right name when queried.
 * Write each datatype using internal and external32.
 * Verify that external32 produces byte-aligned data.
 * Read back each external32 data item as bytes and see
 * that the bytes are correct.
 * Build an external32 struct and see that is extent is
 * reported correctly.
 * Write using a portable datatype interleaved among nodes
 * and see that readback is correct (no stomping because
 * of incorrect scaling).
 * Build a user-defined datarep, write each type, read it back.
 * Check bytes of written data to see that they're correct.
 * See that type extents is reported correctly.
 * Try some stuff with extrastate -- parameterized datareps.
 * Return non-success from a converter function and see
 * what happens.
 * See that returned count is correct for user-defined datarep
 * read and write.
 * Make sure that nonportable types *don't* get scaled.
 * Verify that we can't create a duplicate datarep (including
 * builtin ones)
 * See how unknown datarep strings are handled.
 */

#define BUFSIZE 256
#define ENV_DIRECTORY_VAR "MPIO_USER_PATH"

#ifndef TRUE
# define TRUE 1
#endif
#ifndef FALSE
# define FALSE 0
#endif

#define ENTERING(fun) \
        fprintf(stderr, "(%d)FLOWTRACE: Entering %s\n", rank, fun);

#define LEAVING(fun) \
        fprintf(stderr, "(%d)FLOWTRACE: Leaving %s\n", rank, fun);

#define DEBUG_TRACE(str) \
{ \
        fprintf(stderr, "(%d)%s\n", rank, str); \
}

#define MAKEFILENAME(name, prefix, path, id) \
        sprintf(name, "%s/%s%d", path, prefix, id);

/* Handles a bug in an old version of ROMIO that we compile with sometimes */
#if !defined(MPI_DISTRIBUTE_DFLT_DARG) && defined(MPI_DISTRIBUTE_DFLT_ARG)
#define MPI_DISTRIBUTE_DFLT_DARG MPI_DISTRIBUTE_DFLT_ARG
#endif

#define CHECK(a) \
{ \
        if (!(a)) { \
                fprintf(stderr, \
                        "(%d)Error at node %d, line %d of test program\n", \
                        rank, rank, __LINE__); \
        } \
}

#define CHECKINTS(a, b) \
{ \
        CHECK((int)(a) == (int)(b)); \
        if ((int)(a) != (int)(b)) { \
                fprintf(stderr, "(%d)got: %x expected: %x\n", \
                        rank, (int)(a), (int)(b)); \
        } \
}

#define CHECKERRS(a, b) \
{ \
        char got_string[MPI_MAX_ERROR_STRING]; \
        char expected_string[MPI_MAX_ERROR_STRING]; \
        int  string_len; \
	int ca, cb; \
        if ((int)(a) != (int)(b)) { \
		MPI_Error_class(a, &ca); \
		MPI_Error_class(b, &cb); \
		CHECKINTS(ca, cb); \
		if (ca != cb) { \
                	MPI_Error_string(a, got_string, &string_len); \
                	MPI_Error_string(b, expected_string, &string_len); \
                	fprintf(stderr, "(%d)got %d in class %d:  %s\n", \
                        	rank, (int)(a), (int)ca, got_string); \
			fprintf(stderr, "(%d)expected %d in class %d:  %s\n", \
                        	rank, (int)(b), (int)cb, expected_string); \
		} \
        } \
}


#define CHECKRESULT_INTS(a, b, c) \
{ \
        CHECKINTS( a, b ) \
        if( a != b ) goto c; \
}
 

#define CHECKRESULT(a, b, c) \
{ \
	CHECKERRS( a, b ) \
	if( a != b ) goto c; \
}

struct alltypes {
	long double	ld;
	double		d;	
	long		l;
	unsigned long	ul;
	float		f;
	int		i;
	unsigned	u;
	short		s;
	unsigned short	us;
	char		c;
	unsigned char	uc;
	unsigned char	b;
};

/* Mapentry and Typemap are for the user datarep converters */
typedef struct _mapentry {
	MPI_Aint	disp;
	MPI_Datatype	type;
} Mapentry;

typedef struct _typemap {
	int		refs;
	unsigned	count;
	MPI_Aint	extent;
	Mapentry *	map;
} Typemap;

void dotests( int rank, int size, int pid, MPI_Info hints, char * path );
void test_setgetrep( int rank, int size, int pid, MPI_Info hints, char * path );
void test_readwriteinternal( int rank, int size, int pid, MPI_Info hints,
	char * path );
void test_readwriteexternal32( int rank, int size, int pid, MPI_Info hints,
	char * path );
void test_readwriteuser( int rank, int size, int pid, MPI_Info hints,
	char * path );
void test_scaling( int rank, int size, int pid, MPI_Info hints, char * path );
void test_errors( int rank, int size, int pid, MPI_Info hints, char * path );

Typemap * DecodeType( MPI_Datatype type );
void ShowMap( Typemap * pmap );
void FillBuf( Typemap * pmap, void * b );
int TextRep_extent( MPI_Datatype base, MPI_Aint * extent, void * state );
int TextRep_read_converter( void * userbuf, MPI_Datatype buftype, int count,
	void * filebuf, MPI_Offset position, void * extra_state );
int TextRep_write_converter( void * userbuf, MPI_Datatype buftype, int count,
	void * filebuf, MPI_Offset position, void * extra_state );
int UserTypeMapCopy( MPI_Datatype oldtype, int keyval, void * extra_state,
	void *attr_in, void * attr_out, int * flag );
int UserTypeMapDelete( MPI_Datatype oldtype, int keyval, void * attr,
	void * extra_state );
int UserTypemapInit( int * extra_state );
int FailRep_converter( void * userbuf, MPI_Datatype buftype, int count,
	void * filebuf, MPI_Offset position, void * extra_state );

int keyval = MPI_KEYVAL_INVALID;

int main( int argc, char * argv[] )
{

	int		size, rank;
	int		mpi_result;
	int		pid;
	MPI_Info	hints;
	char		*path;
	

	mpi_result = MPI_Init( &argc, &argv );
	if( mpi_result != MPI_SUCCESS ) {
		fprintf( stderr, "Error %d trying to initialize!\n",
			mpi_result );
		exit( -1 );
	}

	/* Try to keep going after all errors */
	mpi_result = MPI_Errhandler_set( MPI_COMM_WORLD, MPI_ERRORS_RETURN );
	CHECKERRS( mpi_result, MPI_SUCCESS );

	mpi_result = MPI_File_set_errhandler( MPI_FILE_NULL,
			MPI_ERRORS_RETURN );
	CHECKERRS( mpi_result, MPI_SUCCESS );

	mpi_result = MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	CHECKERRS( mpi_result, MPI_SUCCESS );

	mpi_result = MPI_Comm_size( MPI_COMM_WORLD, &size );
	CHECKERRS( mpi_result, MPI_SUCCESS );

	/* Get directory for test files */
	path = getenv( ENV_DIRECTORY_VAR );
	if( path == NULL ) {
		fprintf( stderr, "Set %s to directory for test files\n",
			ENV_DIRECTORY_VAR );
		exit( -1 );
	}

	/* Create the hint structure and set the COS */
	mpi_result = MPI_Info_create( &hints );
	CHECKERRS( mpi_result, MPI_SUCCESS );
	if( mpi_result != MPI_SUCCESS ) exit( -1 );

	/* Broadcast node 0's pid so we can use it in run-specific
 	 * filenames that are the same on all tasks.
	 */
	pid = getpid();
	mpi_result = MPI_Bcast( &pid, 1, MPI_INT, 0, MPI_COMM_WORLD );
	CHECKERRS( mpi_result, MPI_SUCCESS );
	if( mpi_result != MPI_SUCCESS ) exit( -1 );

	/* Here we go... */
	dotests( rank, size, pid, hints, path );

	mpi_result = MPI_Finalize();

	if( mpi_result != MPI_SUCCESS ) {
		fprintf( stderr, "Error %d trying to finalize!\n",
			mpi_result );
		exit( -1 );
	}

	LEAVING("main");

	return 0;
}

void dotests( int rank, int size, int pid, MPI_Info hints, char * path )
{
	ENTERING("dotests");

	/* call each of the tests... */
	test_setgetrep( rank, size, pid, hints, path );
	test_readwriteinternal( rank, size, pid, hints, path );
	test_readwriteexternal32( rank, size, pid, hints, path );
	test_readwriteuser( rank, size, pid, hints, path );
	test_scaling( rank, size, pid, hints, path );
	test_errors( rank, size, pid, hints, path );

	LEAVING("dotests");
}

void test_setgetrep( int rank, int size, int pid, MPI_Info hints, char * path )
{
	MPI_File	fh1 = MPI_FILE_NULL, fh2 = MPI_FILE_NULL;
	MPI_Datatype	etype, filetype;
	MPI_Offset	disp;
	int		mpi_result;
	char		name1[BUFSIZE], name2[BUFSIZE];
	char		datarep1[BUFSIZE], datarep2[BUFSIZE];
	int		amode;

	ENTERING("test_setgetrep");

	DEBUG_TRACE("Checking setting and reading of builtin datareps" );

	/* Create the filenames and amode */
	MAKEFILENAME( name1, "setgetrep1", path, pid );
	MAKEFILENAME( name2, "setgetrep2", path, pid );

	amode = MPI_MODE_CREATE | MPI_MODE_RDWR | MPI_MODE_DELETE_ON_CLOSE;

	/* When we open the file, the default datarep should be native.
	 * Verify that, then open another file and set each file to each of
	 * the three builtin datareps and read them back to be sure they're
	 * correct and don't get mixed up.
	 */

	mpi_result = MPI_File_open( MPI_COMM_WORLD, name1, amode, hints, &fh1 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );

	DEBUG_TRACE("Checking name of default datarep");

	mpi_result = MPI_File_get_view( fh1, &disp, &etype, &filetype,
			datarep1 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );

	if (etype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&etype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if (filetype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&filetype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	/* Might as well test disp too the first time.  The standard
	 * isn't clear about whether etype and filetype are supposed
	 * to be dups or not when they're basic types, so it's harder
	 * to test them.  Also, I don't know if we should free them.
	 */
	CHECK( disp == 0 );
	CHECK( strcmp(datarep1, "native") == 0 );

	/* Now change the datarep on the first file and open a second file */

	DEBUG_TRACE("Checking that changing datarep on one file doesn't affect another");

	mpi_result = MPI_File_set_view( fh1, 0, MPI_BYTE, MPI_BYTE,
		"internal", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );

	mpi_result = MPI_File_open( MPI_COMM_WORLD, name2, amode, hints, &fh2 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );

	/* Check the datareps for both files */
	mpi_result = MPI_File_get_view( fh1, &disp, &etype, &filetype,
			datarep1 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );
	
	CHECK( strcmp(datarep1, "internal") == 0 );

	if (etype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&etype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if (filetype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&filetype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	mpi_result = MPI_File_get_view( fh2, &disp, &etype, &filetype,
			datarep2 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );
	
	CHECK( strcmp(datarep2, "native") == 0 );
	
	if (etype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&etype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if (filetype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&filetype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	/* Change the datareps... */
	mpi_result = MPI_File_set_view( fh1, 0, MPI_BYTE, MPI_BYTE,
		"external32", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );

	mpi_result = MPI_File_set_view( fh2, 0, MPI_BYTE, MPI_BYTE,
		"internal", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );

	/* Check them again... */
	mpi_result = MPI_File_get_view( fh1, &disp, &etype, &filetype,
			datarep1 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );
	
	CHECK( strcmp(datarep1, "external32") == 0 );

	if (etype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&etype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if (filetype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&filetype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	mpi_result = MPI_File_get_view( fh2, &disp, &etype, &filetype,
			datarep2 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );
	
	CHECK( strcmp(datarep2, "internal") == 0 );
	
	if (etype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&etype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if (filetype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&filetype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	/* One more change ... */
	mpi_result = MPI_File_set_view( fh1, 0, MPI_BYTE, MPI_BYTE,
		"native", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );

	mpi_result = MPI_File_set_view( fh2, 0, MPI_BYTE, MPI_BYTE,
		"external32", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );

	/* One more check ... */
	mpi_result = MPI_File_get_view( fh1, &disp, &etype, &filetype,
			datarep1 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );
	
	CHECK( strcmp(datarep1, "native") == 0 );

	if (etype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&etype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if (filetype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&filetype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	mpi_result = MPI_File_get_view( fh2, &disp, &etype, &filetype,
			datarep2 );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endsetget );
	
	CHECK( strcmp(datarep2, "external32") == 0 );

	if (etype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&etype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if (filetype != MPI_BYTE) {
		mpi_result = MPI_Type_free(&filetype);
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	/* Close the files; this should also delete them */

	endsetget:
	if( fh1 != MPI_FILE_NULL ) {
		mpi_result = MPI_File_close( &fh1 );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( fh2 != MPI_FILE_NULL ) {
		mpi_result = MPI_File_close( &fh2 );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	LEAVING("test_setgetrep");

}

#define NTYPES 12
#define NCOPIES 100

void test_readwriteinternal( int rank, int size, int pid, MPI_Info hints,
	char * path )
{
	MPI_File	fh = MPI_FILE_NULL;
	MPI_Datatype	etype = MPI_DATATYPE_NULL, buftype = MPI_DATATYPE_NULL;
	MPI_Offset	disp;
	MPI_Status	status;
	int		mpi_result;
	char		name[BUFSIZE];
	int		amode;
	int		count;
	int		different;
	int		blens[NTYPES + 1];
	MPI_Aint	fdisp[NTYPES], bdisp[NTYPES + 1];
	MPI_Aint	extent;
	MPI_Datatype	basetypes[NTYPES + 1];
	int		i;
	struct alltypes	outbuf[NCOPIES], inbuf[NCOPIES];
	char *		base = (char *) outbuf;

	ENTERING( "test_readwriteinternal" );

	DEBUG_TRACE( "Checking use of \"internal\" data representation" );

	/* Create the filename and amode */
	MAKEFILENAME( name, "readwriteinternal", path, pid );

	amode = MPI_MODE_CREATE | MPI_MODE_RDWR | MPI_MODE_DELETE_ON_CLOSE;

	/* To test the internal datarep, we'll write from node 0 using
	 * all the MPI predefined (C) types, and read the data back from 
	 * all the other nodes.  This should verify that internal is a
	 * consistent representation on all nodes.
	 */

	/* First open the file... */
	mpi_result = MPI_File_open( MPI_COMM_WORLD, name, amode, hints, &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

	/* In order to construct the datatype correctly, we need to know
	 * the extent of each basic type *in the file*.  To get that, we
	 * need to set the datarep on the file before calling
	 * MPI_File_get_type_extent.  We'll set the view again once we've
	 * built the etype.
	 */
	mpi_result = MPI_File_set_view( fh, 0, MPI_BYTE, MPI_BYTE,
			"internal", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

	/* Create a struct of all the (C-language) MPI types.  */
	basetypes[0] = MPI_LONG_DOUBLE;
	basetypes[1] = MPI_DOUBLE;
	basetypes[2] = MPI_LONG;
	basetypes[3] = MPI_UNSIGNED_LONG;
	basetypes[4] = MPI_FLOAT;
	basetypes[5] = MPI_INT;
	basetypes[6] = MPI_UNSIGNED;
	basetypes[7] = MPI_SHORT;
	basetypes[8] = MPI_UNSIGNED_SHORT;
	basetypes[9] = MPI_CHAR;
	basetypes[10] = MPI_UNSIGNED_CHAR;
	basetypes[11] = MPI_BYTE;
	basetypes[12] = MPI_UB;		/* only needed for buftype */

	/* Build the array of displacements by computing the length of
	 * the previous type and adding it to the previous displacement.
	 */
	fdisp[0] = 0;
	blens[0] = 1;
	for( i = 1; i < NTYPES; i++ ) {
		mpi_result = MPI_File_get_type_extent( fh, basetypes[i - 1],
			&extent );
		CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );
		fdisp[i] = fdisp[i - 1] + extent;
		blens[i] = 1;
	}

	mpi_result = MPI_Type_struct( NTYPES, blens, fdisp, basetypes,
		&etype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );
	mpi_result = MPI_Type_commit( &etype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

	/* To do the struct type for the memory side of the transfer,
	 * we'll look at the actual pointer values of the elements so
	 * we can account for any internal alignment holes.  There's
	 * an MPI_UB at the end to make sure the external alignment
	 * gap is set correctly.
	 */
	bdisp[0] = 0;
	bdisp[1] = (char *)&outbuf[0].d - base;
	bdisp[2] = (char *)&outbuf[0].l - base;
	bdisp[3] = (char *)&outbuf[0].ul - base;
	bdisp[4] = (char *)&outbuf[0].f - base;
	bdisp[5] = (char *)&outbuf[0].i - base;
	bdisp[6] = (char *)&outbuf[0].u - base;
	bdisp[7] = (char *)&outbuf[0].s - base;
	bdisp[8] = (char *)&outbuf[0].us - base;
	bdisp[9] = (char *)&outbuf[0].c - base;
	bdisp[10] = (char *)&outbuf[0].uc - base;
	bdisp[11] = (char *)&outbuf[0].b - base;
	bdisp[12] = (char *)&outbuf[1].ld - base;

	blens[12] = 1;

	mpi_result = MPI_Type_struct( NTYPES + 1, blens, bdisp, basetypes,
		&buftype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );
	mpi_result = MPI_Type_commit( &buftype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

	/* Set the view with the new etype and internal datarep */
	mpi_result = MPI_File_set_view( fh, 0, etype, etype, "internal",
			hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

	/* Initialize the data and write from node 0 */

	memset( outbuf, 0, sizeof( outbuf ) );
	memset( inbuf, 0, sizeof( inbuf ) );

	for( i = 0; i < NCOPIES; i++ ) {
		outbuf[i].ld = 0.125L * i;
		outbuf[i].d = (double)i * i * i;
		outbuf[i].l = (1<<30) + i;
		outbuf[i].ul = (1ul<<31) + i;
		outbuf[i].f = 1.5 * i;
		outbuf[i].i = i * i;
		outbuf[i].u = i * i * i;
		outbuf[i].s = i;
		outbuf[i].us = 2 * i;
		outbuf[i].c = 'a' + (i % 26);
		outbuf[i].uc = 'a' + (i % 26) + 128;
		outbuf[i].b = 0xcc ^ i;
	}

	if( rank == 0 ) {
		mpi_result = MPI_File_write( fh, outbuf, NCOPIES, buftype,
			&status );
		CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

		/* Make sure that status got set correctly; count should
		 * be the number of etypes we wrote; elements should be
		 * the count times the number of basic types in the etype.
		 */

		DEBUG_TRACE( "Checking for correct write count" );

		count = 0;
		mpi_result = MPI_Get_count( &status, etype, &count );
		CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

		CHECKINTS( count, NCOPIES );

		count = 0;
		mpi_result = MPI_Get_elements( &status, etype, &count );
		CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

		CHECKINTS( count, NCOPIES * NTYPES );
	} 

	/* Flush the data so it's visible to all the nodes */
	mpi_result = MPI_File_sync( fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );
	
	/* Make sure we can read the data that's been written */

	DEBUG_TRACE( "Checking for correct readback" );

	mpi_result = MPI_File_read_at( fh, 0, inbuf, NCOPIES, buftype,
		&status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

	different = memcmp( inbuf, outbuf, sizeof( inbuf ) );
	CHECKRESULT_INTS( different, 0, endinternal );

	/* Make sure that status got set correctly; count should
	 * be the number of etypes we read; elements should be
	 * the count times the number of basic types in the etype.
	 */

	DEBUG_TRACE( "Checking for correct read count" );

	count = 0;
	mpi_result = MPI_Get_count( &status, etype, &count );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

	CHECKINTS( count, NCOPIES );

	count = 0;
	mpi_result = MPI_Get_elements( &status, etype, &count );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endinternal );

	CHECKINTS( count, NCOPIES * NTYPES );

	endinternal:
	if( fh != MPI_FILE_NULL ) {
		mpi_result = MPI_File_close( &fh );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( etype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &etype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( buftype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &buftype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	LEAVING( "test_readwriteinternal" );
}

#define STRUCTLEN 51
void test_readwriteexternal32( int rank, int size, int pid, MPI_Info hints,
	char * path )
{
	MPI_File	fh = MPI_FILE_NULL;
	MPI_Datatype	etype = MPI_DATATYPE_NULL,
			ftype_data = MPI_DATATYPE_NULL,
			ftype_bytes = MPI_DATATYPE_NULL,
			buftype = MPI_DATATYPE_NULL;
	MPI_Offset	disp;
	MPI_Status	status;
	int		mpi_result;
	char		name[BUFSIZE];
	int		amode;
	int		count;
	int		different;
	int		blens[NTYPES + 1];
	MPI_Aint	fdisp[NTYPES], bdisp[NTYPES + 1];
	MPI_Aint	extent;
	MPI_Datatype	basetypes[NTYPES + 1];
	int		i;
	struct alltypes	databuf[NCOPIES], compdata[NCOPIES];
	char *		base = (char *) databuf;
	unsigned char	bytebuf[STRUCTLEN * NCOPIES];

	ENTERING( "test_readwriteexternal32" );

	DEBUG_TRACE( "Checking use of \"external32\" data representation" );

	/* Create the filename and amode */
	MAKEFILENAME( name, "readwriteexternal32", path, pid );

	amode = MPI_MODE_CREATE | MPI_MODE_RDWR | MPI_MODE_DELETE_ON_CLOSE;

	/* Test the external32 datarep by writing our databuf
	 * and looking for a specific set of bytes when we read back.
	 * The we'll write the bytes that form our bytebuf in the
	 * external32 datarep and see if they get translated correctly
	 * to the right data values when we read them back.  Note that
	 * the data in the file should be byte aligned.
	 */

	/* First open the file... */
	mpi_result = MPI_File_open( MPI_COMM_WORLD, name, amode, hints, &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* In order to construct the datatype correctly, we need to know
	 * the extent of each basic type *in the file*.  To get that, we
	 * need to set the datarep on the file before calling
	 * MPI_File_get_type_extent.  We'll set the view again once we've
	 * built the etype.
	 */
	mpi_result = MPI_File_set_view( fh, 0, MPI_BYTE, MPI_BYTE,
		"external32", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* Create a struct of all the (C-language) MPI types.  */
	basetypes[0] = MPI_LONG_DOUBLE;
	basetypes[1] = MPI_DOUBLE;
	basetypes[2] = MPI_LONG;
	basetypes[3] = MPI_UNSIGNED_LONG;
	basetypes[4] = MPI_FLOAT;
	basetypes[5] = MPI_INT;
	basetypes[6] = MPI_UNSIGNED;
	basetypes[7] = MPI_SHORT;
	basetypes[8] = MPI_UNSIGNED_SHORT;
	basetypes[9] = MPI_CHAR;
	basetypes[10] = MPI_UNSIGNED_CHAR;
	basetypes[11] = MPI_BYTE;
	basetypes[12] = MPI_UB;		/* only needed for buftype */

	/* Build the array of displacements by computing the length of
	 * the previous type and adding it to the previous displacement.
	 */
	fdisp[0] = 0;
	blens[0] = 1;
	for( i = 1; i < NTYPES; i++ ) {
		mpi_result = MPI_File_get_type_extent( fh, basetypes[i - 1],
			&extent );
		CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );
		fdisp[i] = fdisp[i - 1] + extent;
		blens[i] = 1;
	}

	mpi_result = MPI_Type_struct( NTYPES, blens, fdisp, basetypes,
		&etype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );
	mpi_result = MPI_Type_commit( &etype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* To do the struct type for the memory side of the transfer,
	 * we'll look at the actual pointer values of the elements so
	 * we can account for any internal alignment holes.  There's
	 * an MPI_UB at the end to make sure the external alignment
	 * gap is set correctly.
	 */
	bdisp[0] = 0;
	bdisp[1] = (char *)&databuf[0].d - base;
	bdisp[2] = (char *)&databuf[0].l - base;
	bdisp[3] = (char *)&databuf[0].ul - base;
	bdisp[4] = (char *)&databuf[0].f - base;
	bdisp[5] = (char *)&databuf[0].i - base;
	bdisp[6] = (char *)&databuf[0].u - base;
	bdisp[7] = (char *)&databuf[0].s - base;
	bdisp[8] = (char *)&databuf[0].us - base;
	bdisp[9] = (char *)&databuf[0].c - base;
	bdisp[10] = (char *)&databuf[0].uc - base;
	bdisp[11] = (char *)&databuf[0].b - base;
	bdisp[12] = (char *)&databuf[1].ld - base;

	blens[12] = 1;

	mpi_result = MPI_Type_struct( NTYPES + 1, blens, bdisp, basetypes,
		&buftype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );
	mpi_result = MPI_Type_commit( &buftype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );


	/* Now we'll create a view that has each task write to a
	 * different part of the file.  We'll need a filetype for that.
	 */
	
	mpi_result = MPI_File_get_type_extent( fh, etype, &extent );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* The etype struct should be exactly STRUCTLEN bytes. */
	CHECKINTS( extent, STRUCTLEN );

	blens[0] = blens[1] = blens[2] = 1;
	fdisp[0] = 0;
	fdisp[1] = extent * rank;
	fdisp[2] = extent * size;
	basetypes[0] = MPI_LB;
	basetypes[1] = etype;
	basetypes[2] = MPI_UB;
	mpi_result = MPI_Type_struct( 3, blens, fdisp, basetypes, &ftype_data );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );
	mpi_result = MPI_Type_commit( &ftype_data );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );
	
	/* Set the view with the new etype and external32 datarep */
	mpi_result = MPI_File_set_view( fh, 0, etype, ftype_data,
			"external32", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* Initialize the data and write from all nodes */

	memset( databuf, 0, sizeof( databuf ) );

	for( i = 0; i < NCOPIES; i++ ) {
		databuf[i].ld = 0.125L * i;
		databuf[i].d = (double)i * i * i;
		databuf[i].l = (1<<30) + i;
		databuf[i].ul = (1<<31) + i;
		databuf[i].f = 1.5 * i;
		databuf[i].i = i * i;
		databuf[i].u = i * i * i;
		databuf[i].s = i;
		databuf[i].us = 2 * i;
		databuf[i].c = 'a' + (i % 26);
		databuf[i].uc = 'a' + (i % 26) + 128;
		databuf[i].b = 0xcc ^ i;
	}
	memcpy( compdata, databuf, sizeof( compdata ) );

	mpi_result = MPI_File_write( fh, databuf, NCOPIES, buftype,
		&status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* Make sure that status got set correctly; count should
	 * be the number of etypes we wrote; elements should be
	 * the count times the number of basic types in the etype.
	 */

	DEBUG_TRACE( "Checking for correct write count" );

	count = 0;
	mpi_result = MPI_Get_count( &status, etype, &count );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	CHECKINTS( count, NCOPIES );

	count = 0;
	mpi_result = MPI_Get_elements( &status, etype, &count );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	CHECKINTS( count, NCOPIES * NTYPES );

	/* Flush the data so it's visible to all the nodes */
	mpi_result = MPI_File_sync( fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );
	

	/* Now read back the data in the form of raw bytes.
	 * The total length of the struct with no alignment holes
	 * should be STRUCTLEN bytes, so we create a view to read
	 * chunks of that length in round-robin form.
	 */

	blens[0] = blens[2] = 1;
	blens[1] = STRUCTLEN;
	fdisp[0] = 0;
	fdisp[1] = STRUCTLEN * rank;
	fdisp[2] = STRUCTLEN * size;
	basetypes[0] = MPI_LB;
	basetypes[1] = MPI_BYTE;
	basetypes[2] = MPI_UB;
	mpi_result = MPI_Type_struct( 3, blens, fdisp, basetypes,
			&ftype_bytes );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );
	mpi_result = MPI_Type_commit( &ftype_bytes );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );
	
	mpi_result = MPI_File_set_view( fh, 0, MPI_BYTE, ftype_bytes,
			"external32", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* Read the data that's been written */

	DEBUG_TRACE( "Checking for correct readback" );

	memset( bytebuf, 0, sizeof( bytebuf ) );
	mpi_result = MPI_File_read_at( fh, 0, bytebuf, NCOPIES * STRUCTLEN,
		MPI_BYTE, &status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	different = memcmp( bytebuf, compbytes, sizeof( bytebuf ) );
	CHECKRESULT_INTS( different, 0, endexternal32 );

	/* Close the file, which will remove it. */
	mpi_result = MPI_File_close( &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* Now write out the bytes and see if we can read them back
	 * as correct data.  This time we'll do collective I/O.
	 */

	DEBUG_TRACE( "Checking format for external32 data" );

	mpi_result = MPI_File_open( MPI_COMM_WORLD, name, amode, hints, &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* We shouln't need to set external32 for this to work */
	mpi_result = MPI_File_set_view( fh, 0, MPI_BYTE, ftype_bytes,
			"native", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	mpi_result = MPI_File_write_all( fh, compbytes, NCOPIES * STRUCTLEN,
		MPI_BYTE, &status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* Now reset the view and read back as external32 */
	mpi_result = MPI_File_set_view( fh, 0, etype, ftype_data,
			"external32", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	memset( databuf, 0, sizeof( databuf ) );
	mpi_result = MPI_File_read_at_all( fh, 0, databuf, NCOPIES, buftype,
		&status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	/* Verify the data */
	different = memcmp( databuf, compdata, sizeof( databuf ) );
	CHECKRESULT_INTS( different, 0, endexternal32 );
	
	/* Verify the counts */
	count = 0;
	mpi_result = MPI_Get_count( &status, etype, &count );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	CHECKINTS( count, NCOPIES );

	count = 0;
	mpi_result = MPI_Get_elements( &status, etype, &count );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endexternal32 );

	CHECKINTS( count, NCOPIES * NTYPES );

	endexternal32:
	if( fh != MPI_FILE_NULL ) {
		mpi_result = MPI_File_close( &fh );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( etype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &etype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( ftype_data != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &ftype_data );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( ftype_bytes != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &ftype_bytes );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( buftype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &buftype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	LEAVING( "test_readwriteexternal32" );
}

void test_readwriteuser( int rank, int size, int pid, MPI_Info hints,
	char * path )
{
	MPI_File	fh = MPI_FILE_NULL;
	MPI_Datatype	etype = MPI_DATATYPE_NULL, buftype = MPI_DATATYPE_NULL;
	MPI_Offset	disp;
	MPI_Status	status;
	int		mpi_result;
	char		name[BUFSIZE];
	int		amode;
	int		count;
	int		different;
	int		blens[NTYPES + 1];
	MPI_Aint	fdisp[NTYPES], bdisp[NTYPES + 1];
	MPI_Aint	extent;
	MPI_Datatype	basetypes[NTYPES + 1];
	int		i;
	struct alltypes	outbuf[NCOPIES], inbuf[NCOPIES];
	char *		base = (char *) outbuf;

	ENTERING( "test_readwriteuser" );

	DEBUG_TRACE( "Checking use of \"text\" (user-defined) data representation" );

	/* Create the filename and amode */
	MAKEFILENAME( name, "readwriteuser", path, pid );

	amode = MPI_MODE_CREATE | MPI_MODE_RDWR | MPI_MODE_DELETE_ON_CLOSE;

	/* To test the user datarep, we'll write from node 0 using
	 * all the MPI predefined (C) types, and read the data back from 
	 * all the other nodes.  
	 */

	/* First open the file... */
	mpi_result = MPI_File_open( MPI_COMM_WORLD, name, amode, hints, &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

	/* In order to construct the datatype correctly, we need to know
	 * the extent of each basic type *in the file*.  To get that, we
	 * need to set the datarep on the file before calling
	 * MPI_File_get_type_extent.  Before we can set the view, we have
	 * to register the datarap.
	 */

	/* This creates a keyval we can use to cache typemaps on
	 * datatypes.  The keyval can be used for any datarep that
	 * uses DecodeType to build a typemap.  We have to initialize
	 * here and not in the converter functions to be sure that the
	 * keyval is allocated exactly once.
	 */
	if( keyval == MPI_KEYVAL_INVALID ) {
		UserTypemapInit( &keyval );

		mpi_result =
			MPI_Register_datarep( "text",
				TextRep_read_converter,
				TextRep_write_converter,
				TextRep_extent, &keyval );
		CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );
	}

	mpi_result = MPI_File_set_view( fh, 0, MPI_BYTE, MPI_BYTE,
			"text", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

	/* Create a struct of all the (C-language) MPI types.  */
	basetypes[0] = MPI_LONG_DOUBLE;
	basetypes[1] = MPI_DOUBLE;
	basetypes[2] = MPI_LONG;
	basetypes[3] = MPI_UNSIGNED_LONG;
	basetypes[4] = MPI_FLOAT;
	basetypes[5] = MPI_INT;
	basetypes[6] = MPI_UNSIGNED;
	basetypes[7] = MPI_SHORT;
	basetypes[8] = MPI_UNSIGNED_SHORT;
	basetypes[9] = MPI_CHAR;
	basetypes[10] = MPI_UNSIGNED_CHAR;
	basetypes[11] = MPI_BYTE;
	basetypes[12] = MPI_UB;		/* only needed for buftype */

	/* Build the array of displacements by computing the length of
	 * the previous type and adding it to the previous displacement.
	 */
	fdisp[0] = 0;
	blens[0] = 1;
	for( i = 1; i < NTYPES; i++ ) {
		mpi_result = MPI_File_get_type_extent( fh, basetypes[i - 1],
			&extent );
		CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );
		fdisp[i] = fdisp[i - 1] + extent;
		blens[i] = 1;
	}

	mpi_result = MPI_Type_struct( NTYPES, blens, fdisp, basetypes,
		&etype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );
	mpi_result = MPI_Type_commit( &etype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

	/* To do the struct type for the memory side of the transfer,
	 * we'll look at the actual pointer values of the elements so
	 * we can account for any internal alignment holes.  There's
	 * an MPI_UB at the end to make sure the external alignment
	 * gap is set correctly.
	 */
	bdisp[0] = 0;
	bdisp[1] = (char *)&outbuf[0].d - base;
	bdisp[2] = (char *)&outbuf[0].l - base;
	bdisp[3] = (char *)&outbuf[0].ul - base;
	bdisp[4] = (char *)&outbuf[0].f - base;
	bdisp[5] = (char *)&outbuf[0].i - base;
	bdisp[6] = (char *)&outbuf[0].u - base;
	bdisp[7] = (char *)&outbuf[0].s - base;
	bdisp[8] = (char *)&outbuf[0].us - base;
	bdisp[9] = (char *)&outbuf[0].c - base;
	bdisp[10] = (char *)&outbuf[0].uc - base;
	bdisp[11] = (char *)&outbuf[0].b - base;
	bdisp[12] = (char *)&outbuf[1].ld - base;

	blens[12] = 1;

	mpi_result = MPI_Type_struct( NTYPES + 1, blens, bdisp, basetypes,
		&buftype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );
	mpi_result = MPI_Type_commit( &buftype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

	/* Set the view with the new etype and internal datarep */
	mpi_result = MPI_File_set_view( fh, 0, etype, etype, "text",
			hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

	/* Initialize the data and write from node 0 */

	memset( outbuf, 0, sizeof( outbuf ) );
	memset( inbuf, 0, sizeof( inbuf ) );

	for( i = 0; i < NCOPIES; i++ ) {
		outbuf[i].ld = 0.125L * i;
		outbuf[i].d = (double)i * i * i;
		outbuf[i].l = (1<<30) + i;
		outbuf[i].ul = (1ul<<31) + i;
		outbuf[i].f = 1.5 * i;
		outbuf[i].i = i * i;
		outbuf[i].u = i * i * i;
		outbuf[i].s = i;
		outbuf[i].us = 2 * i;
		outbuf[i].c = 'a' + (i % 26);
		outbuf[i].uc = 'a' + (i % 26) + 128;
		outbuf[i].b = 0xcc ^ i;
	}

	if( rank == 0 ) {

		DEBUG_TRACE( "Checking write call with user datarep" );

		mpi_result = MPI_File_write( fh, outbuf, NCOPIES, buftype,
			&status );
		CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

		/* Make sure that status got set correctly; count should
		 * be the number of etypes we wrote; elements should be
		 * the count times the number of basic types in the etype.
		 */

		DEBUG_TRACE( "Checking write count with user datarep" );

		count = 0;
		mpi_result = MPI_Get_count( &status, etype, &count );
		CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

		CHECKINTS( count, NCOPIES );

		count = 0;
		mpi_result = MPI_Get_elements( &status, etype, &count );
		CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

		CHECKINTS( count, NCOPIES * NTYPES );
	} 

	/* Flush the data so it's visible to all the nodes */
	mpi_result = MPI_File_sync( fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );
	
	/* Make sure we can read the data that's been written */

	DEBUG_TRACE( "Checking readback with user datarep" );

	memset( inbuf, 0, sizeof( inbuf ) );
	mpi_result = MPI_File_read_at( fh, 0, inbuf, NCOPIES, buftype,
		&status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

	different = memcmp( inbuf, outbuf, sizeof( inbuf ) );
	CHECKRESULT_INTS( different, 0, enduser );

	/* Make sure that status got set correctly; count should
	 * be the number of etypes we read; elements should be
	 * the count times the number of basic types in the etype.
	 */

	DEBUG_TRACE( "Checking read count with user datarep" );

	count = 0;
	mpi_result = MPI_Get_count( &status, etype, &count );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

	CHECKINTS( count, NCOPIES );

	count = 0;
	mpi_result = MPI_Get_elements( &status, etype, &count );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enduser );

	CHECKINTS( count, NCOPIES * NTYPES );

	enduser:
	if( fh != MPI_FILE_NULL ) {
		mpi_result = MPI_File_close( &fh );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( etype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &etype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( buftype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &buftype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	LEAVING( "test_readwriteuser" );
}

/*
 *  DATASIZE should be divisible by #processors for test_scaling in
 *  order to be able to use a darray type to write and an equivalent 
 *  indexed type to read.
 */
#define DATASIZE	120	

void test_scaling( int rank, int size, int pid, MPI_Info hints, char * path )
{
	MPI_File	fh = MPI_FILE_NULL;
	MPI_Status	status;
	int		mpi_result;
	char		name[BUFSIZE];
	int		amode;
	float		fout[DATASIZE];
	float		fin[DATASIZE];
	int		gsizes, distribs, dargs, psizes;
	MPI_Datatype	darraytype = MPI_DATATYPE_NULL,
			indextype = MPI_DATATYPE_NULL,
			structtype = MPI_DATATYPE_NULL,
			contigtype = MPI_DATATYPE_NULL;
	MPI_Datatype	typelist[2];
	MPI_Aint	adisps[2];
	int		i, count;
	int		blens[DATASIZE], disps[DATASIZE];
	char		chout[20], chin[140];

	ENTERING( "test_scaling" );

	DEBUG_TRACE( "Checking scaling of portable datatypes" );

	/* Create the filename and amode */
	MAKEFILENAME( name, "scaling", path, pid );

	amode = MPI_MODE_CREATE | MPI_MODE_RDWR | MPI_MODE_DELETE_ON_CLOSE;

	/* To test scaling, we'll create a round-robin type, write
	 * from all nodes, and then read back.  If the type got scaled,
	 * the data should come back correct, even though the user rep we're
	 * using is bigger than any native rep.
	 */

	/* First open the file... */
	mpi_result = MPI_File_open( MPI_COMM_WORLD, name, amode, hints, &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	/* Only register the datarep if we haven't done so before. */
	if( keyval == MPI_KEYVAL_INVALID ) {
		UserTypemapInit( &keyval );

		mpi_result = MPI_Register_datarep( "text",
				TextRep_read_converter,
				TextRep_write_converter,
				TextRep_extent, &keyval );
		CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );
	}

	/* Create distributed array type */
	gsizes = DATASIZE * size;
	distribs = MPI_DISTRIBUTE_CYCLIC;
	psizes = size;
	dargs = MPI_DISTRIBUTE_DFLT_DARG;

	mpi_result = MPI_Type_create_darray( size, rank, 1, &gsizes,
			&distribs, &dargs, &psizes, MPI_ORDER_C,
			MPI_FLOAT, &darraytype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );
	mpi_result = MPI_Type_commit( &darraytype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	mpi_result = MPI_File_set_view( fh, 0, MPI_FLOAT, darraytype,
			"text", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	for( i = 0; i < DATASIZE; i++ ) {
		fout[i] = i * 71 * rank;	/* 71 is just a random # */
	}

	/* Send out the data, interleaved */
	mpi_result = MPI_File_write_all( fh, fout, DATASIZE, MPI_FLOAT,
						&status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	mpi_result = MPI_File_sync( fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	/* Read the data back with an index type, which should also
	 * scale correctly.
	 */
	for( count = 0, i = rank; count < DATASIZE; count++, i += size ) {
		blens[count] = 1;
		disps[count] = i;
	}
	
	mpi_result = MPI_Type_indexed( count, blens, disps, MPI_FLOAT,
			&indextype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	mpi_result = MPI_Type_commit( &indextype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	mpi_result = MPI_File_set_view( fh, 0, MPI_FLOAT, indextype,
			"text", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	mpi_result = MPI_File_read_all( fh, fin, DATASIZE, MPI_FLOAT, &status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	CHECK( memcmp( fin, fout, sizeof(fin)) == 0 );

	mpi_result = MPI_File_close( &fh );
	CHECKERRS( mpi_result, MPI_SUCCESS );

	/* Now try a nonportable type and see if gets scaled when it
	 * shouldn't be.
	 */
	typelist[0] = typelist[1] = MPI_CHAR;
	adisps[0] = 0;
	adisps[1] = 7;	/* a char takes seven bytes in this rep */
	blens[0] = blens[1] = 1;
	mpi_result = MPI_Type_struct( 2, blens, adisps, typelist, &structtype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );
	mpi_result = MPI_Type_commit( &structtype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	/* Bury this nonportable struct in a portable contiguous type */
	mpi_result = MPI_Type_contiguous( 10, structtype, &contigtype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );
	mpi_result = MPI_Type_commit( &contigtype );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );
	
	mpi_result = MPI_File_open( MPI_COMM_WORLD, name, amode, hints, &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	mpi_result = MPI_File_set_view( fh, 0, MPI_CHAR, contigtype,
			"text", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	memset( chout, 'Q', sizeof(chout) );
	mpi_result = MPI_File_write_at_all( fh, rank * 20, chout, 20, MPI_CHAR,
			&status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	/* If all went well, we should have a contiguous set of text-rep
	 * bytes in the file with no gaps or overlap.  To check, we'll
	 * read the whole file back in using native rep and compare the
	 * bytes to the string we expect.
	 */
	mpi_result = MPI_File_set_view( fh, rank * 140, MPI_CHAR, MPI_CHAR,
			"native", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	mpi_result = MPI_File_read_all( fh, chin, 140, MPI_CHAR, &status );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );
	
	CHECK( memcmp( chin, chcheck, sizeof(chin)) == 0 );

	mpi_result = MPI_File_close( &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, endscaling );

	endscaling:
	if( darraytype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &darraytype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( structtype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &structtype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( contigtype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &contigtype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( indextype != MPI_DATATYPE_NULL ) {
		mpi_result = MPI_Type_free( &indextype );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}
	if( fh != MPI_FILE_NULL ) {
		mpi_result = MPI_File_close( &fh );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	LEAVING( "test_scaling" );
}

void test_errors( int rank, int size, int pid, MPI_Info hints, char * path )
{
	MPI_File	fh = MPI_FILE_NULL;
	MPI_Status	status;
	int		mpi_result, class;
	char		name[BUFSIZE];
	int		amode;

	ENTERING( "test_errors" );

	DEBUG_TRACE( "Checking error handling" );

	/* Create the filename and amode */
	MAKEFILENAME( name, "errors", path, pid );

	/* MPI_MAX_DATAREP_STRING has to be >= 64 */
	CHECK( MPI_MAX_DATAREP_STRING >= 64 );

	amode = MPI_MODE_CREATE | MPI_MODE_RDWR | MPI_MODE_DELETE_ON_CLOSE;

	mpi_result = MPI_File_open( MPI_COMM_WORLD, name, amode, hints, &fh );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enderrors );
	
	/* Set a view with a bogus datarep */
	mpi_result = MPI_File_set_view( fh, 0, MPI_CHAR, MPI_CHAR,
			"bogusdatarep", hints );
	MPI_Error_class( mpi_result, &class );
	CHECKERRS( class, MPI_ERR_UNSUPPORTED_DATAREP );

	/* Create a datarep with the same name as an exisiting datarep */
	mpi_result = MPI_Register_datarep( "external32",
			TextRep_read_converter,
			TextRep_write_converter,
			TextRep_extent, &keyval );
	MPI_Error_class( mpi_result, &class );
	CHECKERRS( class, MPI_ERR_DUP_DATAREP );

	/* Again, only with a user-defined rep name */
	/* This one should work... */
	mpi_result = MPI_Register_datarep( "duplicate",
			TextRep_read_converter,
			TextRep_write_converter,
			TextRep_extent, &keyval );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enderrors );
	
	/* This one should fail... */
	mpi_result = MPI_Register_datarep( "duplicate",
			MPI_CONVERSION_FN_NULL,
			MPI_CONVERSION_FN_NULL,
			TextRep_extent, &keyval );
	MPI_Error_class( mpi_result, &class );
	CHECKERRS( class, MPI_ERR_DUP_DATAREP );

	/* See what happens when a datarep converter returns an
 	 * error.  We should get MPI_ERR_CONVERSION back.
	 */
	mpi_result = MPI_Register_datarep( "failing",
			FailRep_converter, FailRep_converter,
			TextRep_extent, &keyval );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enderrors );

	mpi_result = MPI_File_set_view( fh, 0, MPI_CHAR, MPI_CHAR,
		"failing", hints );
	CHECKRESULT( mpi_result, MPI_SUCCESS, enderrors );

	mpi_result = MPI_File_write( fh, name, sizeof(name), MPI_CHAR,
			&status );
	MPI_Error_class( mpi_result, &class );
	CHECKERRS( class, MPI_ERR_CONVERSION );
	
	mpi_result = MPI_File_read( fh, name, sizeof(name), MPI_CHAR,
			&status );
	MPI_Error_class( mpi_result, &class );
	CHECKERRS( class, MPI_ERR_CONVERSION );

	enderrors:
	if( fh != MPI_FILE_NULL ) {
		mpi_result = MPI_File_close( &fh );
		CHECKERRS( mpi_result, MPI_SUCCESS );
	}

	LEAVING( "test_errors" );
}

/* Here begin the user-defined datarep conversion functions */

/* Extent function for text datarep */
int TextRep_extent( MPI_Datatype base, MPI_Aint * extent, void * state )
{
	int	result = MPI_SUCCESS;

	state = state;		/* state is explicitly not used */

	/* All types have a trailing space; float types are always in
	 * exponential format with leading sign, and wide enough for
	 * sign, decimal, exponent marker, exponent sign, mantissa,
	 * and exponent.  Signed integer values have leading sign.
	 * Character values are in the form '\xdd'.
	 */
	if( base == MPI_LONG_DOUBLE ) {
		*extent = 43;	/* 4+34+4+1 */
	} 
	else if( base == MPI_DOUBLE ) {
		*extent = 24;	/* 4+16+3+1 */
	}
	else if( base == MPI_FLOAT ) {
		*extent = 15;	/* 4+8+2+1 */
	}
	else if( base == MPI_LONG || base == MPI_INT ) {
		*extent = 12;	/* 1+10+1 */
	}
	else if( base == MPI_UNSIGNED_LONG || base == MPI_UNSIGNED ) {
		*extent = 11;	/* 10+1 */
	}
	else if( base == MPI_SHORT ) {
		*extent = 7;	/* 1+5+1 */
	}
	else if( base == MPI_UNSIGNED_SHORT ) {
		*extent = 6;	/* 5+1 */
	}
	else if( base == MPI_CHAR || base == MPI_UNSIGNED_CHAR
		|| base == MPI_BYTE ) {
		*extent = 7;	/* 6+1 (see format above) */
	}
	else {
		result = MPI_ERR_CONVERSION;
	}

	return result;
}

/* Read function for text datarep */
int TextRep_read_converter( void * userbuf, MPI_Datatype buftype, int count,
	void * filebuf, MPI_Offset position, void * extra_state )
{
	int		keyval = *((int *)extra_state);
	int		attrpresent;
	Typemap *	themap;
	int		i;
	MPI_Offset	addr;
	char *		source = filebuf;
	void *		dest;
	int		result = MPI_SUCCESS;

	/* See if there is a typemap cached on the datatype; if
	 * not, build one and cache it.  Presumably, there was
	 * an initialization that set the extra_state
	 * to an MPI-defined attribute key that we can use to
	 * get the map.
	 */
	result = MPI_Type_get_attr( buftype, keyval, &themap, &attrpresent );
	if( !attrpresent && result == MPI_SUCCESS ) {
		themap = DecodeType( buftype );
		if( themap == NULL ) return MPI_ERR_CONVERSION;

		/* There's a potential race here if multiple threads
		 * are doing conversions at once using this type.
		 * However, I believe that the worst that can happen
		 * is that the threads will all build the same typemap
		 * and cache them on the type.  As long as MPI is
		 * thread safe, the last one cached will stick, and
		 * each successive caching operation will erase the
		 * earlier copy of the typemap.
		 */
		result = MPI_Type_set_attr( buftype, keyval, themap );
	}

	if (result != MPI_SUCCESS) result = MPI_ERR_CONVERSION;
	
	/* Loop over count entries in the type; for each entry, use
	 * the MPI type to determine which conversion to do and
	 * use the offset (= typemap offset + (extent * (cur pos / nelements))
	 * to determine where to store the result in the user buffer.
	 */
	for( i = 0; i < count && result == MPI_SUCCESS; i++ ) {
		int		index = (position + i) % themap->count;
		MPI_Datatype	t = themap->map[index].type;
		MPI_Aint	extent;

		dest = (char *)userbuf + themap->map[index].disp
			+ ((position + i) / themap->count) * themap->extent;
		
		if( t == MPI_LONG_DOUBLE ) {
			sscanf( source, "%Lf", (long double *)dest );
		}
		else if( t == MPI_DOUBLE ) {
			*((double *)dest) = strtod( source, NULL );
		}
		else if( t == MPI_FLOAT ) {
			*((float *)dest) = strtof( source, NULL );
		}
		else if( t == MPI_LONG || t == MPI_INT ) {
			*((long *)dest) = strtol( source, NULL, 10 );
		}
		else if( t == MPI_UNSIGNED_LONG || t == MPI_UNSIGNED ) {
			*((unsigned long *)dest)
				= strtoul( source, NULL, 10 );
		}
		else if( t == MPI_SHORT ) {
			*((short *)dest) = strtol( source, NULL, 10 );
		}
		else if( t == MPI_UNSIGNED_SHORT ) {
			*((unsigned short *)dest)
				= strtoul( source, NULL, 10 );
		}
		else if( t == MPI_CHAR || t == MPI_UNSIGNED_CHAR 
			|| t == MPI_BYTE ) {
			/* Skip leading '\x characters */
			*((unsigned char *)dest)
				= strtoul( source + 3, NULL, 16 );
		}
		else {
			result = MPI_ERR_CONVERSION;
		}

		TextRep_extent( t, &extent, NULL );
		source += extent;	/* skip to next item */
	}

	return result;
}

/* Write function for text datarep */
int TextRep_write_converter( void * userbuf, MPI_Datatype buftype, int count,
	void * filebuf, MPI_Offset position, void * extra_state )
{
	int		keyval = *((int *)extra_state);
	int		attrpresent;
	Typemap *	themap;
	int		i;
	MPI_Offset	addr;
	void *		source;
	char *		dest = filebuf;
	int		result = MPI_SUCCESS;

	/* See if there is a typemap cached on the datatype; if
	 * not, build one and cache it.  Presumably, there was
	 * an initialization that set the extra_state
	 * to an MPI-defined attribute key that we can use to
	 * get the map.
	 */
	result = MPI_Type_get_attr( buftype, keyval, &themap, &attrpresent );
	if( !attrpresent && result == MPI_SUCCESS ) {
		themap = DecodeType( buftype );
		if( themap == NULL ) return MPI_ERR_CONVERSION;

		/* There's a potential race here if multiple threads
		 * are doing conversions at once using this type.
		 * However, I believe that the worst that can happen
		 * is that the threads will all build the same typemap
		 * and cache them on the type.  As long as MPI is
		 * thread safe, the last one cached will stick, and
		 * each successive caching operation will erase the
		 * earlier copy of the typemap.
		 */
		result = MPI_Type_set_attr( buftype, keyval, themap );
	}
	
	if (result != MPI_SUCCESS) result = MPI_ERR_CONVERSION;
	
	/* Loop over count entries in the type; for each entry, use
	 * the MPI type to determine which conversion to do and
	 * use the offset (= typemap offset + (extent * (cur pos / nelements))
	 * to determine where to store the result in the user buffer.
	 */
	for( i = 0; i < count && result == MPI_SUCCESS; i++ ) {
		int		index = (position + i) % themap->count;
		MPI_Datatype	t = themap->map[index].type;
		int		chars;

		source = (char *)userbuf + themap->map[index].disp
			+ ((position + i) / themap->count) * themap->extent;
		
		if( t == MPI_LONG_DOUBLE ) {
			chars = sprintf( dest, "%42.33Le ",
				*((long double *)source) );
		}
		else if( t == MPI_DOUBLE ) {
			chars = sprintf( dest, "%23.15e ",
				*((double *)source) );
		}
		else if( t == MPI_FLOAT ) {
			chars = sprintf( dest, "%14.7e ", *((float *)source) );
		}
		else if( t == MPI_LONG ) {
			chars = sprintf( dest, "%+11ld ", *((long *)source) );
		}
		else if( t == MPI_INT ) {
			chars = sprintf( dest, "%+11d ", *((int *)source) );
		}
		else if( t == MPI_UNSIGNED_LONG ) {
			chars = sprintf( dest, "%10lu ",
				*((unsigned long *)source) );
		}
		else if( t == MPI_UNSIGNED ) {
			chars = sprintf( dest, "%10u ", *((unsigned *)source) );
		}
		else if( t == MPI_SHORT ) {
			chars = sprintf( dest, "%+6hd ", *((short *)source) );
		}
		else if( t == MPI_UNSIGNED_SHORT ) {
			chars = sprintf( dest, "%5hu ", 
				*((unsigned short*)source) );
		}
		else if( t == MPI_CHAR || t == MPI_UNSIGNED_CHAR
			|| t == MPI_BYTE ) {
			chars = sprintf( dest, "'\\x%02x' ",
				 *((unsigned char *)source) );
		}
		else {
			result = MPI_ERR_CONVERSION;
		}

		if( chars < 0 ) result = MPI_ERR_CONVERSION;
		dest += chars;
	}

	return result;
}

Typemap *
DecodeType( MPI_Datatype type )
{
	Typemap	*	themap;
	int		totalsize;
	int		lastindex;
	int		ingap;
	MPI_Aint	extent;
	int		integers, addresses, types, combiner;
	int		lastints = 0, lastaddrs = 0, lasttypes = 0;
	int *		intarray = NULL;
	MPI_Aint *	addrarray = NULL;
	MPI_Datatype *	typearray = NULL;
	int		loopagain;
	int		i, j, k;
	int		mpi_result;
	
	mpi_result = MPI_Type_size( type, &totalsize );
	if( mpi_result != MPI_SUCCESS ) return NULL;

	/* The size is an upper limit on the number of typemap entries */
	themap = (Typemap *)malloc( sizeof(Typemap) );
	if( themap == NULL ) return NULL;
	themap->map = (Mapentry *)malloc( sizeof(Mapentry) * totalsize );
	if( themap->map == NULL ) {
		free( themap );
		return NULL;
	}

	memset( themap->map, -1, sizeof(Mapentry) * totalsize );

	mpi_result = MPI_Type_extent( type, &themap->extent );
	if( mpi_result != MPI_SUCCESS ) goto cleanup;
	themap->count = totalsize;	/* needed for debugging only */
	
	/* Place the initial type at index 0 (remember that the
	 * the index is *not* the displacement). Then repeatedly
	 * run through the array decoding each type that is not
	 * predefined.  We leave space for each type to be decoded
	 * further by skipping its size before going to the next item.
	 * This leaves a potentially sparse array; we'll compress it
	 * at the end, but we have to keep it in order.  When we
	 * run through the whole array without seeing a derived
	 * type, we're done.
	 */
	themap->map[0].type = type;
	themap->map[0].disp = 0;
	lastindex = 0;
	do {
		int		count, blocklen, stride;
		int		sofar;
		int		size;
		MPI_Aint	stridea;
		MPI_Aint	base;
		MPI_Datatype	newtype;
		
		loopagain = 0;
		for( i = 0; i < totalsize; i++ ) {
			if( themap->map[i].disp == -1 ) continue;

			mpi_result =
				MPI_Type_get_envelope( themap->map[i].type,
				&integers, &addresses, &types, &combiner );
			if( mpi_result != MPI_SUCCESS ) goto cleanup;

			if( combiner == MPI_COMBINER_NAMED ) continue;
		
			loopagain = 1;

			/* Make arrays big enough (or allocate them ) */
			if( integers > lastints ) {
				intarray = (int *)realloc( intarray,
						integers * sizeof(int) );
				lastints = integers;
			}
		
			if( addresses > lastaddrs ) {
				addrarray = (MPI_Aint *)realloc( addrarray,
						addresses * sizeof(MPI_Aint) );
				lastaddrs = addresses;
			}

			if( types > lasttypes ) {
				typearray = (MPI_Datatype *)realloc( typearray,
					types * sizeof(MPI_Datatype)  );
				lasttypes = types;
			}

			if( (intarray == NULL && integers != 0) ||
				(addrarray == NULL && addresses != 0 ) ||
				(typearray == NULL && types != 0 ) ) {
				mpi_result = MPI_ERR_INTERN;
				goto cleanup;
			}

			mpi_result =
				MPI_Type_get_contents( themap->map[i].type,
					integers, addresses, types, intarray,
					addrarray, typearray );
			if( mpi_result != MPI_SUCCESS ) goto cleanup;

			mpi_result = MPI_Type_size( typearray[0], &size );
			if( mpi_result != MPI_SUCCESS ) goto cleanup;
			mpi_result = MPI_Type_extent( typearray[0], &extent );
			if( mpi_result != MPI_SUCCESS ) goto cleanup;
			
			switch( combiner ) {
			case MPI_COMBINER_DUP:
				themap->map[i].type = typearray[0];
				break;
			case MPI_COMBINER_CONTIGUOUS:
				count = intarray[0];
				base = themap->map[i].disp;
				for( j = 0; j < count; j++ ) {
					themap->map[i + j * size].type
						= typearray[0];
					themap->map[i + j * size].disp
						= base + j * extent;
				}
				break;
			case MPI_COMBINER_VECTOR:
				count = intarray[0];
				blocklen = intarray[1];
				stride = intarray[2];
				base = themap->map[i].disp;
				for( j = 0, sofar = i; j < count; j++ ) {
					for( k = 0; k < blocklen;
						k++, sofar += size ) {
						themap->map[sofar].type
							= typearray[0];
						themap->map[sofar].disp
							= base
							+ j * stride * extent
							+ k * extent;
					}
				}
				break;
			case MPI_COMBINER_HVECTOR_INTEGER:
			case MPI_COMBINER_HVECTOR:
			/* I'm ignoring the difference until I figure out
			 * what it means.
			 */
				count = intarray[0];
				blocklen = intarray[1];
				stridea = addrarray[0];
				base = themap->map[i].disp;
				for( j = 0, sofar = i; j < count; j++ ) {
					for( k = 0; k < blocklen;
						k++, sofar += size ) {
						themap->map[sofar].type
							= typearray[0];
						themap->map[sofar].disp
							= base
							+ j * stridea
							+ k * extent;
					}
				}
				break;
			case MPI_COMBINER_INDEXED:
				count = intarray[0];
				base = themap->map[i].disp;
				themap->map[i].type = -1;
				themap->map[i].disp = -1;
				for( j = 0, sofar = i; j < count; j++ ) {
					for( k = 0; k < intarray[j+1];
						k++, sofar += size ) {
						themap->map[sofar].type
							= typearray[0];
						themap->map[sofar].disp
							= base
							+ ( intarray[count+1+j]
							+ k ) * extent;
					}
				}
				break;
			case MPI_COMBINER_HINDEXED_INTEGER:
			case MPI_COMBINER_HINDEXED:
				count = intarray[0];
				base = themap->map[i].disp;
				themap->map[i].type = -1;
				themap->map[i].disp = -1;
				for( j = 0, sofar = i; j < count; j++ ) {
					for( k = 0; k < intarray[j+1];
						k++, sofar += size ) {
						themap->map[sofar].type
							= typearray[0];
						themap->map[sofar].disp
							= base
							+ addrarray[j]
							+ k * extent;
					}
				}
				break;
			case MPI_COMBINER_INDEXED_BLOCK:	
				count = intarray[0];
				base = themap->map[i].disp;
				themap->map[i].type = -1;
				themap->map[i].disp = -1;
				for( j = 0, sofar = i; j < count; j++ ) {
					for( k = 0; k < intarray[1];
						k++, sofar += size ) {
						themap->map[sofar].type
							= typearray[0];
						themap->map[sofar].disp
							= base
							+ ( intarray[2+j] + k )
							* extent;
					}
				}
				break;
			case MPI_COMBINER_STRUCT_INTEGER:
			case MPI_COMBINER_STRUCT:
				count = intarray[0];
				base = themap->map[i].disp;
				themap->map[i].type = -1;
				themap->map[i].disp = -1;
				for( j = 0, sofar = i; j < count; j++ ) {
					newtype = typearray[j];
					if( newtype == MPI_LB ||
						newtype == MPI_UB ) {
						continue;
					}
					mpi_result =
					    MPI_Type_extent( newtype, &extent );
					if( mpi_result != MPI_SUCCESS )
					    goto cleanup;
					mpi_result = 
					    MPI_Type_size( newtype, &size );
					if( mpi_result != MPI_SUCCESS )
					    goto cleanup;
					for( k = 0; k < intarray[j+1];
						k++, sofar += size ) {
						themap->map[sofar].type
							= newtype;
						themap->map[sofar].disp
							= base
							+ addrarray[j]
							+ k * extent;
					}
				}
				break;
			case MPI_COMBINER_SUBARRAY:
			{	MPI_Aint	items;
				int		slab, pos;
				int		order;
				int		*arraysize, *subsize,
						*start;
				int		*slabsize;

				MPI_Type_extent( themap->map[i].type, &items );

				items /= extent;	/* elements in array */
		
				count = intarray[0];
				base = themap->map[i].disp;
				themap->map[i].type = -1;
				themap->map[i].disp = -1;
				
				arraysize = intarray + 1;
				subsize = intarray + count + 1;
				start = intarray + 2 * count + 1;
				order = intarray[3 * count + 1];

				slabsize = (int *)malloc(count * sizeof(int) );
				if( slabsize == NULL ) {
					mpi_result = MPI_ERR_INTERN;
					goto cleanup;
				}
				if( order == MPI_ORDER_C ) {
					slabsize[count - 1] = 1;
					for( j = count - 2; j >= 0; j-- ) {
						slabsize[j] = slabsize[j+1]
							* arraysize[j+1];
					}
				} else {	/* Fortran order */
					slabsize[0] = 1;
					for( j = 1; j < count; j++ ) {
						slabsize[j] = slabsize[j-1]
							* arraysize[j-1];
					}
				}
						
				/* Look at each element in the full array and
				 * see if it's in range in all dimensions of
				 * the subarray.  Do this by dividing the
				 * array into slabs of decreasing dimension
				 * and checking the position of the slab
				 * within the next higher dimension.
				 */
				for( j = 0, sofar = i; j < items; j++ ) {
					int	inrange = 1;
					pos = j;
					if( order == MPI_ORDER_C ) {
						for( k = 0; k < count; k++ ) {
							slab = pos /
								 slabsize[k];
							if( slab >= start[k]
							&& slab < start[k]
							+ subsize[k] ) {
								pos %=
								slabsize[k];
							} else {
								inrange = 0;
								break;
							}
						}
					} else { 	/* Fortran order */
						for( k = count - 1; k >= 0;
								k-- ){
							slab = pos /
								 slabsize[k];
							if( slab >= start[k]
							&& slab < start[k]
							+ subsize[k] ) {
								pos %=
								slabsize[k];
							} else {
								inrange = 0;
								break;
							}
						}
					}
					if( inrange ) {
						themap->map[sofar].type
							= typearray[0];	
						themap->map[sofar].disp
							= base + j * extent;
						sofar += size;
					}
				}
				free( slabsize );
			}
				break;
			case MPI_COMBINER_DARRAY:
				fprintf( stderr, "Can't decode darrays\n" );
				mpi_result = MPI_ERR_INTERN;
				goto cleanup;
			default:
				fprintf( stderr, "Unknown combiner %d\n",
					combiner );
				mpi_result = MPI_ERR_INTERN;
				goto cleanup;
			}
		}
	} while( loopagain );

	/* Now compress the type map so all the valid entries are at
	 * the beginning.  Then we can reallocate it to throw away the
	 * unused space.
	 */
	ingap = 0;
	for( i = 0; i < totalsize; i++ ) {
		
		/* Move the next valid entry to the front of the gap.
		 * Note that once we're in a gap, we're always in one
		 * because moving the entry at the far end of the gap
		 * to the front doesn't make the gap any smaller.
		 */
		if( ingap && themap->map[i].disp != -1 ) {
			themap->map[lastindex].disp = themap->map[i].disp;
			themap->map[lastindex].type = themap->map[i].type;
			++lastindex;
		}
		/* Look for start of gap (marked by invalid displacement */
		else if( !ingap && themap->map[i].disp == -1 ) {
			lastindex = i;
			ingap = 1;
		}
	}

	if( !ingap ) lastindex = totalsize;	/* map was densely packed */
	themap->count = lastindex;
	themap->map = (Mapentry *) realloc( themap->map,
					themap->count * sizeof(Mapentry) );
	if( themap->map == NULL )
		mpi_result = MPI_ERR_INTERN;
	else
		themap->refs = 1;		/* one reference so far */

	cleanup:
	if( intarray != NULL ) free( intarray ); 
	if( addrarray != NULL ) free( addrarray );
	if( typearray != NULL ) free( typearray );
	if( mpi_result != MPI_SUCCESS ) {
		free( themap->map );
		free( themap );
		themap = NULL;
	}

	return themap;
} /* DecodeType */

void ShowMap( Typemap * pmap )
{
	int	i;

	printf("Extent: %ld Count: %ld\n", pmap->extent, pmap->count );

	for( i = 0; i < pmap->count; i++ ) {
		MPI_Datatype t;
		char * s;

		if( pmap->map[i].disp == -1 ) continue;
		t = pmap->map[i].type;
		if( t == MPI_PACKED ) s = "MPI_PACKED";
		else if( t == MPI_BYTE ) s = "MPI_BYTE";
		else if( t == MPI_CHAR ) s = "MPI_CHAR";
		else if( t == MPI_UNSIGNED_CHAR ) s = "MPI_UNSIGNED_CHAR";
#ifdef MPI_SIGNED_CHAR
		else if( t == MPI_SIGNED_CHAR ) s = "MPI_SIGNED_CHAR";
#endif /* MPI_SIGNED_CHAR */
#ifdef MPI_WCHAR
		else if( t == MPI_WCHAR ) s = "MPI_WCHAR";
#endif /* MPI_WCHAR */
		else if( t == MPI_SHORT ) s = "MPI_SHORT";
		else if( t == MPI_UNSIGNED_SHORT ) s = "MPI_UNSIGNED_SHORT";
		else if( t == MPI_INT ) s = "MPI_INT";
		else if( t == MPI_UNSIGNED ) s = "MPI_UNSIGNED";
		else if( t == MPI_LONG ) s = "MPI_LONG";
		else if( t == MPI_UNSIGNED_LONG ) s = "MPI_UNSIGNED_LONG";
		else if( t == MPI_FLOAT ) s = "MPI_FLOAT";
		else if( t == MPI_DOUBLE ) s = "MPI_DOUBLE";
		else if( t == MPI_LONG_DOUBLE ) s = "MPI_LONG_DOUBLE";
		else if( t == MPI_CHARACTER ) s = "MPI_CHARACTER";
		else if( t == MPI_LOGICAL ) s = "MPI_LOGICAL";
		else if( t == MPI_INTEGER ) s = "MPI_INTEGER";
		else if( t == MPI_REAL ) s = "MPI_REAL";
		else if( t == MPI_DOUBLE_PRECISION ) s = "MPI_DOUBLE_PRECISION";
		else if( t == MPI_COMPLEX ) s = "MPI_COMPLEX";
		else if( t == MPI_DOUBLE_COMPLEX ) s = "MPI_DOUBLE_COMPLEX";
		else if( t == MPI_UB ) s = "MPI_UB";	/* shouldn't happen */
		else if( t == MPI_LB ) s = "MPI_LB";	/* this either */
		else s = "unknown";

		printf("%d %s (%d) %ld\n", i, s, t, pmap->map[i].disp );
	}
}

void FillBuf( Typemap * pmap, void * b )
{
	int	i;
	void *	dest;

	printf("Filling buffer...\n");

	for( i = 0; i < pmap->count; i++ ) {
		MPI_Datatype t;

		if( pmap->map[i].disp == -1 ) continue;
		t = pmap->map[i].type;
		dest = (char *)b + pmap->map[i].disp;
		
		if( t == MPI_PACKED ) {
			*((char *)dest) = (unsigned char)i;
		}
		else if( t == MPI_BYTE ) {
			*((char *)dest) = (unsigned char)i;
		}
		else if( t == MPI_CHAR ) {
			*((char *)dest) = (unsigned char)i;
		}
		else if( t == MPI_UNSIGNED_CHAR ) {
			*((char *)dest) = (unsigned char)i;
		}
#ifdef MPI_SIGNED_CHAR
		else if( t == MPI_SIGNED_CHAR ) {
			*((char *)dest) = (signed char)i;
		}
#endif /* MPI_SIGNED_CHAR */
		else if( t == MPI_SHORT ) {
			*((short *)dest) = (short)i;
		}
		else if( t == MPI_UNSIGNED_SHORT ) {
			*((unsigned short *)dest) = (unsigned short)i;
		}
		else if( t == MPI_INT ) {
			*((int *)dest) = i;
		}
		else if( t == MPI_UNSIGNED ) {
			*((int *)dest) = i;
		}
		else if( t == MPI_LONG ) {
			*((long *)dest) = i;
		}
		else if( t == MPI_UNSIGNED_LONG ) {
			*((unsigned long *)dest) = i;
		}
		else if( t == MPI_FLOAT ) {
			*((float *)dest) = i;
		}
		else if( t == MPI_DOUBLE ) {
			*((double *)dest) = i;
		}
		else if( t == MPI_LONG_DOUBLE ) {
			*((long double *)dest) = i;
		}

	}
	printf("Done\n");
}

/* Duplicate a type map when the type itself is duplicated. */
int UserTypeMapCopy( MPI_Datatype oldtype, int keyval, void * extra_state,
	void *attr_in, void * attr_out, int * flag )
{
	Typemap *	themap = attr_in;

	oldtype = oldtype;		/* avoid compiler warnings */
	keyval = keyval;
	extra_state = extra_state;

	++(themap->refs);		/* use the same type map */

	*(void **)attr_out = attr_in;	/* need to copy attr_in to attr_out */

	*flag = 1;			/* don't delete attr in the new type */
	
	return MPI_SUCCESS;
}

int UserTypeMapDelete( MPI_Datatype oldtype, int keyval, void * attr,
	void * extra_state )
{
	Typemap *	themap = attr;

	oldtype = oldtype;		/* avoid compiler warnings */
	keyval = keyval;
	extra_state = extra_state;

	if( --(themap->refs) <= 0 ) {
		free( themap->map );
		free( themap );
	}

	return MPI_SUCCESS;
}
		
int UserTypemapInit( int * extra_state )
{
	int	keyval;
	int	result;
	
	result = MPI_Type_create_keyval( UserTypeMapCopy, UserTypeMapDelete,
		&keyval, NULL );

	*extra_state = keyval;

	return result;
}

/* This converter just returns a conversion error to see how MPI
 * handles the failure.
 */
 
int FailRep_converter( void * userbuf, MPI_Datatype buftype, int count,
	void * filebuf, MPI_Offset position, void * extra_state )
{
	/* Return something other than MPI_ERR_CONVERSION to make
	 * sure the value does NOT just get passed through; the
	 * standard says the read/write function should return
	 * MPI_ERR_CONVERSION no matter what error the converter
	 * returns.
	 */
	return MPI_ERR_IO;
}


