/* textdata.h */
/* This declares the string used to check the results of a scaling
 * test for the user-defined "text" datarep.  The string contains
 * the character 'Q' repeated 20 times in "text" format.  The \\
 * should merge into one \ character, and the trailing \0 at the
 * end of the string is NOT part of the test data.
 */
char chcheck[] = "'\\x51' '\\x51' '\\x51' '\\x51' '\\x51' '\\x51' '\\x51' \
'\\x51' '\\x51' '\\x51' '\\x51' '\\x51' '\\x51' '\\x51' '\\x51' '\\x51' \
'\\x51' '\\x51' '\\x51' '\\x51' ";
